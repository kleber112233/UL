package errors;

/**
 * Representa erros encontrados na análise semântica.
 * Ex.: variável não declarada, tipos incompatíveis etc.
 */
public class SemanticError extends RuntimeException {
    private final int linha;

    public SemanticError(String mensagem, int linha) {
        super("Erro semântico na linha " + linha + ": " + mensagem);
        this.linha = linha;
    }

    public int getLinha() { return linha; }
}
