package errors;

/**
 * Representa erros encontrados na análise sintática.
 * Ex.: token inesperado, estrutura inválida etc.
 */
public class ParserError extends RuntimeException {
    private final int linha;
    private final int coluna;

    public ParserError(String mensagem, int linha, int coluna) {
        super("Erro sintático na linha " + linha + ", coluna " + coluna + ": " + mensagem);
        this.linha = linha;
        this.coluna = coluna;
    }

    public int getLinha() { return linha; }
    public int getColuna() { return coluna; }
}
