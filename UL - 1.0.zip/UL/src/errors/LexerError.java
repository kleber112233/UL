package errors;

/**
 * Representa um erro ocorrido durante a análise léxica.
 * É lançado quando o lexer encontra um caractere ou sequência inválida.
 */
public class LexerError extends RuntimeException {

    private final int linha;
    private final int coluna;

    public LexerError(String mensagem, int linha, int coluna) {
        super(String.format("Erro léxico na linha %d, coluna %d: %s", linha, coluna, mensagem));
        this.linha = linha;
        this.coluna = coluna;
    }

    public int getLinha() {
        return linha;
    }

    public int getColuna() {
        return coluna;
    }

    @Override
    public String toString() {
        return String.format("LexerError[l=%d, c=%d, msg=%s]", linha, coluna, getMessage());
    }
}
