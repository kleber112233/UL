package interpreter;

import parser.AST;
import lexer.Token;

import java.util.HashMap;
import java.util.Map;

/**
 * Interpretador da linguagem UL.
 * Executa a AST mantendo variáveis em memória.
 */
public class Interpreter {

    // memória de variáveis: nome -> valor (Integer, Boolean, String)
    private final Map<String, Object> memoria = new HashMap<>();

    /** Executa uma lista/programa inteiro. */
    public void executarPrograma(java.util.List<AST.No> nos) {
        for (AST.No no : nos) {
            executar(no);
        }
    }

    /** Executa um nó (declaração, atribuição, if, loop, out, bloco). */
    public void executar(AST.No no) {
        if (no instanceof AST.VarDecl) {
            executarVarDecl((AST.VarDecl) no);
        } else if (no instanceof AST.Atribuicao) {
            executarAtribuicao((AST.Atribuicao) no);
        } else if (no instanceof AST.If) {
            executarIf((AST.If) no);
        } else if (no instanceof AST.Loop) {
            executarLoop((AST.Loop) no);
        } else if (no instanceof AST.Out) {
            executarOut((AST.Out) no);
        } else if (no instanceof AST.Bloco) {
            for (AST.No cmd : ((AST.Bloco) no).comandos) executar(cmd);
        } // nós de expressão são avaliados somente via avaliar()
    }

    // ---------------- Declarações / Atribuições ----------------

    private void executarVarDecl(AST.VarDecl decl) {
        Object valor = avaliar(decl.inicializador);
        memoria.put(decl.identificador.getLexema(), valor);
    }

    private void executarAtribuicao(AST.Atribuicao atrib) {
        Object valor = avaliar(atrib.valor);
        memoria.put(atrib.identificador.getLexema(), valor);
    }

    // ---------------- Controle de fluxo ----------------

    private void executarIf(AST.If cmd) {
        boolean cond = asBool(avaliar(cmd.condicao));
        if (cond) {
            executar(cmd.blocoThen);
        } else if (cmd.blocoElse != null) {
            executar(cmd.blocoElse);
        }
    }

    private void executarLoop(AST.Loop cmd) {
        while (asBool(avaliar(cmd.condicao))) {
            executar(cmd.corpo);
        }
    }

    private void executarOut(AST.Out cmd) {
        Object v = avaliar(cmd.expressao);
        System.out.println(v);
    }

    // ---------------- Expressões ----------------

    private Object avaliar(AST.No no) {
        if (no instanceof AST.Literal) {
            Token t = ((AST.Literal) no).valor;
            switch (t.getTipo()) {
                case NUMERO:   return Integer.parseInt(t.getLexema());
                case BOOLEANO: return Boolean.parseBoolean(t.getLexema());
                case STRING:   return t.getLexema(); // já vem sem aspas do Lexer
            }
        }

        if (no instanceof AST.Variavel) {
            String nome = ((AST.Variavel) no).nome.getLexema();
            if (!memoria.containsKey(nome)) {
                throw new RuntimeException("Variável '" + nome + "' não declarada em tempo de execução.");
            }
            return memoria.get(nome);
        }

        if (no instanceof AST.Unario) {
            Object dir = avaliar(((AST.Unario) no).direita);
            Token op = ((AST.Unario) no).operador;
            switch (op.getTipo()) {
                case MENOS:   return -asInt(dir);
                case NEGACAO: return !asBool(dir);
            }
        }

        if (no instanceof AST.Binario) {
            Object esq = avaliar(((AST.Binario) no).esquerda);
            Object dir = avaliar(((AST.Binario) no).direita);
            Token op = ((AST.Binario) no).operador;

            switch (op.getTipo()) {
                // aritméticos
                case MAIS:  return asInt(esq) + asInt(dir);
                case MENOS: return asInt(esq) - asInt(dir);
                case MULT:  return asInt(esq) * asInt(dir);
                case DIV: {
                    int d = asInt(dir);
                    if (d == 0) throw new RuntimeException("Divisão por zero.");
                    return asInt(esq) / d;
                }
                case MOD: {
                    int d = asInt(dir);
                    if (d == 0) throw new RuntimeException("Módulo por zero.");
                    return asInt(esq) % d;
                }

                // comparações (retornam boolean)
                case IGUAL:        return esq.equals(dir);
                case DIFERENTE:    return !esq.equals(dir);
                case MAIOR:        return asInt(esq) >  asInt(dir);
                case MAIOR_IGUAL:  return asInt(esq) >= asInt(dir);
                case MENOR:        return asInt(esq) <  asInt(dir);
                case MENOR_IGUAL:  return asInt(esq) <= asInt(dir);

                // lógicos
                case E_LOGICO:  return asBool(esq) && asBool(dir);
                case OU_LOGICO: return asBool(esq) || asBool(dir);
            }
        }

        // não deveria chegar aqui se a AST estiver correta
        return null;
    }

    // ---------------- Helpers de tipo ----------------

    private int asInt(Object v) {
        if (v instanceof Integer) return (Integer) v;
        throw new RuntimeException("Valor não-inteiro em operação aritmética: " + v);
    }

    private boolean asBool(Object v) {
        if (v instanceof Boolean) return (Boolean) v;
        throw new RuntimeException("Valor não-booleano em operação lógica/condição: " + v);
    }
}
