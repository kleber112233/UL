import lexer.Lexer;
import lexer.Token;
import parser.Parser;
import parser.AST;
import parser.AnalisadorSemantico;
import errors.LexerError;
import errors.ParserError;
import errors.SemanticError;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== 🧠 Teste do Analisador Semântico UL ===\n");

        // Código UL de exemplo: inclui casos válidos e inválidos
        String codigo = """
            // --- DECLARAÇÕES ---
            int x = 10
            bool ativo = true
            int y = 3
            bool ok = false

            // --- TESTE DE ATRIBUIÇÕES ---
            x = x + 5         // ✅ válido
            ativo = false     // ✅ válido
            y = ativo         // ❌ tipo incompatível
            z = 5             // ❌ variável não declarada
            int x = 7         // ❌ variável já declarada

            // --- EXPRESSÕES ---
            bool teste = (x > 3) && ativo
            bool errado = x + ativo  // ❌ tipos incompatíveis

            // --- CONTROLE ---
            if (ativo)
                out(x)
            else
                out("Fim")
            fim

            loop (x < 10)
                x = x + 1
            fim

            out("Fim do teste semântico")
            fim
        """;

        try {
            // 1️⃣ Análise Léxica
            System.out.println("=== 🧩 Etapa Léxica ===");
            Lexer lexer = new Lexer(codigo);
            List<Token> tokens = lexer.analisar();
            System.out.println("✓ " + tokens.size() + " tokens gerados com sucesso.\n");

            // 2️⃣ Análise Sintática
            System.out.println("=== 🧱 Etapa Sintática ===");
            Parser parser = new Parser(tokens);
            List<AST.No> arvore = parser.parsePrograma();
            System.out.println("✓ AST construída com sucesso.\n");

            // 3️⃣ Análise Semântica (multi-erro)
            System.out.println("=== 🧠 Etapa Semântica ===");
            AnalisadorSemantico semantico = new AnalisadorSemantico();

            for (AST.No no : arvore) {
                semantico.analisar(no);
            }

            List<SemanticError> erros = semantico.getErros();
            if (erros.isEmpty()) {
                System.out.println("\n✅ Nenhum erro semântico detectado!");
            } else {
                System.out.println("\n❌ Foram encontrados " + erros.size() + " erros semânticos:\n");
                for (SemanticError e : erros) {
                    System.out.println("   • " + e.getMessage());
                }
            }

        } catch (LexerError e) {
            System.err.println("❌ Erro léxico: " + e.getMessage());
        } catch (ParserError e) {
            System.err.println("❌ Erro sintático: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("❌ Erro inesperado: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
