package parser;

import lexer.Token;
import java.util.List;

/** Representação da Árvore Sintática Abstrata (AST). */
public class AST {
    public static abstract class No {}

    // ---------------- Declarações ----------------
    public static class VarDecl extends No {
        public final Token tipo;
        public final Token identificador;
        public final No inicializador;
        public VarDecl(Token tipo, Token identificador, No inicializador) {
            this.tipo = tipo;
            this.identificador = identificador;
            this.inicializador = inicializador;
        }
        public String toString() {
            return "VarDecl(" + tipo.getLexema() + " " +
                    identificador.getLexema() + " = " + inicializador + ")";
        }
    }

    public static class Atribuicao extends No {
        public final Token identificador;
        public final No valor;
        public Atribuicao(Token identificador, No valor) {
            this.identificador = identificador;
            this.valor = valor;
        }
        public String toString() {
            return "Atribuicao(" + identificador.getLexema() + " = " + valor + ")";
        }
    }

    // ---------------- Expressões ----------------
    public static class Literal extends No {
        public final Token valor;
        public Literal(Token valor) {
            this.valor = valor;
        }
        public String toString() {
            return "Literal(" + valor.getLexema() + ")";
        }
    }

    public static class Variavel extends No {
        public final Token nome;
        public Variavel(Token nome) {
            this.nome = nome;
        }
        public String toString() {
            return "Variavel(" + nome.getLexema() + ")";
        }
    }

    public static class Binario extends No {
        public final No esquerda;
        public final Token operador;
        public final No direita;
        public Binario(No esquerda, Token operador, No direita) {
            this.esquerda = esquerda;
            this.operador = operador;
            this.direita = direita;
        }
        public String toString() {
            return "Binario(" + esquerda + " " + operador.getLexema() + " " + direita + ")";
        }
    }

    public static class Unario extends No {
        public final Token operador;
        public final No direita;
        public Unario(Token operador, No direita) {
            this.operador = operador;
            this.direita = direita;
        }
        public String toString() {
            return "Unario(" + operador.getLexema() + " " + direita + ")";
        }
    }

    /** Expressão sozinha como comando (ex: "!5", "-true") */
    public static class Expressao extends No {
        public final No expr;
        public Expressao(No expr) {
            this.expr = expr;
        }
        public String toString() {
            return "Expr(" + expr + ")";
        }
    }

    // ---------------- Comandos de Controle ----------------
    public static class If extends No {
        public final No condicao;
        public final No blocoThen;
        public final No blocoElse;
        public If(No condicao, No blocoThen, No blocoElse) {
            this.condicao = condicao;
            this.blocoThen = blocoThen;
            this.blocoElse = blocoElse;
        }
        public String toString() {
            return "If(cond=" + condicao +
                    ", then=" + blocoThen +
                    (blocoElse != null ? ", else=" + blocoElse : "") + ")";
        }
    }

    public static class Loop extends No {
        public final No condicao;
        public final No corpo;
        public Loop(No condicao, No corpo) {
            this.condicao = condicao;
            this.corpo = corpo;
        }
        public String toString() {
            return "Loop(cond=" + condicao + ", corpo=" + corpo + ")";
        }
    }

    public static class Out extends No {
        public final No expressao;
        public Out(No expressao) {
            this.expressao = expressao;
        }
        public String toString() {
            return "Out(" + expressao + ")";
        }
    }

    public static class Bloco extends No {
        public final List<No> comandos;
        public Bloco(List<No> comandos) {
            this.comandos = comandos;
        }
        public String toString() {
            return "Bloco" + comandos;
        }
    }
}
