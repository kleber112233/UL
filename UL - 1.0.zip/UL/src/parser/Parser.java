package parser;

import lexer.Token;
import lexer.Token.Tipo;
import errors.ParserError;
import java.util.List;
import java.util.ArrayList;

/**
 * Analisador Sintático da linguagem UL.
 * Constrói uma AST a partir da lista de tokens.
 */
public class Parser {
    private final List<Token> tokens;
    private final List<ParserError> erros = new ArrayList<>();
    private int atual = 0;

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
    }

    /** Ponto de entrada: analisa o programa inteiro. */
    public List<AST.No> parsePrograma() {
        List<AST.No> nos = new ArrayList<>();
        while (!estaNoFinal()) {
            AST.No decl = parseDeclaracao();
            if (decl != null) {
                nos.add(decl);
            }
        }
        return nos;
    }

    public List<ParserError> getErros() {
        return erros;
    }

    // ---------------- Declarações ----------------

    private AST.No parseDeclaracao() {
        try {
            if (verificar(Tipo.INT) || verificar(Tipo.BOOL)) {
                return parseVarDecl();
            }
            if (verificar(Tipo.IDENTIFICADOR)) {
                return parseAtribuicao();
            }
            if (verificar(Tipo.IF)) {
                return parseIf();
            }
            if (verificar(Tipo.LOOP)) {
                return parseLoop();
            }
            if (verificar(Tipo.OUT)) {
                return parseOut();
            }
            // Permite expressão sozinha como comando
            if (ehInicioExpressao()) {
                AST.No expr = parseExpressao();
                return new AST.Expressao(expr);
            }

            reportarErro("Esperado declaração ou comando");
            sincronizar();
            return null;
        } catch (ParserError e) {
            erros.add(e);
            sincronizar();
            return null;
        }
    }

    private AST.VarDecl parseVarDecl() {
        Token tipo = avancar(); // INT ou BOOL
        Token nome = consumir(Tipo.IDENTIFICADOR, "Esperado nome da variável");
        consumir(Tipo.ATRIBUICAO, "Esperado '=' após nome da variável");
        AST.No inicializador = parseExpressao();
        return new AST.VarDecl(tipo, nome, inicializador);
    }

    private AST.Atribuicao parseAtribuicao() {
        Token nome = avancar(); // IDENTIFICADOR
        consumir(Tipo.ATRIBUICAO, "Esperado '=' na atribuição");
        AST.No valor = parseExpressao();
        return new AST.Atribuicao(nome, valor);
    }

    // ---------------- Expressões ----------------

    private AST.No parseExpressao() {
        return parseLogicoOu();
    }

    // nível 7: ||
    private AST.No parseLogicoOu() {
        AST.No expr = parseLogicoE();
        while (verificar(Tipo.OU_LOGICO)) {
            Token operador = avancar();
            AST.No direita = parseLogicoE();
            expr = new AST.Binario(expr, operador, direita);
        }
        return expr;
    }

    // nível 6: &&
    private AST.No parseLogicoE() {
        AST.No expr = parseIgualdade();
        while (verificar(Tipo.E_LOGICO)) {
            Token operador = avancar();
            AST.No direita = parseIgualdade();
            expr = new AST.Binario(expr, operador, direita);
        }
        return expr;
    }

    // nível 5: ==, !=
    private AST.No parseIgualdade() {
        AST.No expr = parseComparacao();
        while (verificar(Tipo.IGUAL) || verificar(Tipo.DIFERENTE)) {
            Token operador = avancar();
            AST.No direita = parseComparacao();
            expr = new AST.Binario(expr, operador, direita);
        }
        return expr;
    }

    // nível 4: <, <=, >, >=
    private AST.No parseComparacao() {
        AST.No expr = parseTermo();
        while (verificar(Tipo.MENOR) || verificar(Tipo.MENOR_IGUAL) ||
               verificar(Tipo.MAIOR) || verificar(Tipo.MAIOR_IGUAL)) {
            Token operador = avancar();
            AST.No direita = parseTermo();
            expr = new AST.Binario(expr, operador, direita);
        }
        return expr;
    }

    // nível 3: +, -
    private AST.No parseTermo() {
        AST.No expr = parseFator();
        while (verificar(Tipo.MAIS) || verificar(Tipo.MENOS)) {
            Token operador = avancar();
            AST.No direita = parseFator();
            expr = new AST.Binario(expr, operador, direita);
        }
        return expr;
    }

    // nível 2: *, /, %
    private AST.No parseFator() {
        AST.No expr = parseUnario();
        while (verificar(Tipo.MULT) || verificar(Tipo.DIV) || verificar(Tipo.MOD)) {
            Token operador = avancar();
            AST.No direita = parseUnario();
            expr = new AST.Binario(expr, operador, direita);
        }
        return expr;
    }

    // nível 2: unário (!, -)
    private AST.No parseUnario() {
        if (verificar(Tipo.NEGACAO) || verificar(Tipo.MENOS)) {
            Token operador = avancar();
            AST.No direita = parseUnario();
            return new AST.Unario(operador, direita);
        }
        return parsePrimario();
    }

    // nível 1: literais, identificadores, parênteses
    private AST.No parsePrimario() {
        if (verificar(Tipo.NUMERO) || verificar(Tipo.BOOLEANO) || verificar(Tipo.STRING)) {
            return new AST.Literal(avancar());
        }
        if (verificar(Tipo.IDENTIFICADOR)) {
            return new AST.Variavel(avancar());
        }
        if (verificar(Tipo.ABRE_PAR)) {
            avancar(); // consome '('
            AST.No expr = parseExpressao();
            consumir(Tipo.FECHA_PAR, "Esperado ')' após expressão");
            return expr;
        }
        reportarErro("Esperado expressão");
        return new AST.Literal(new Token(Tipo.STRING, "", olhar().getLinha(), olhar().getColuna()));
    }

    // ---------------- Comandos de controle ----------------

    private AST.If parseIf() {
        consumir(Tipo.IF, "Esperado 'if'");
        consumir(Tipo.ABRE_PAR, "Esperado '(' após if");
        AST.No condicao = parseExpressao();
        consumir(Tipo.FECHA_PAR, "Esperado ')' após condição");

        AST.No blocoThen = parseBloco();
        AST.No blocoElse = null;
        if (verificar(Tipo.ELSE)) {
            avancar();
            blocoElse = parseBloco();
        }
        consumir(Tipo.FIM, "Esperado 'fim' após if");
        return new AST.If(condicao, blocoThen, blocoElse);
    }

    private AST.Loop parseLoop() {
        consumir(Tipo.LOOP, "Esperado 'loop'");
        consumir(Tipo.ABRE_PAR, "Esperado '(' após loop");
        AST.No condicao = parseExpressao();
        consumir(Tipo.FECHA_PAR, "Esperado ')' após condição");

        AST.No corpo = parseBloco();
        consumir(Tipo.FIM, "Esperado 'fim' após loop");
        return new AST.Loop(condicao, corpo);
    }

    private AST.Out parseOut() {
        consumir(Tipo.OUT, "Esperado 'out'");
        consumir(Tipo.ABRE_PAR, "Esperado '(' após out");
        AST.No expr = parseExpressao();
        consumir(Tipo.FECHA_PAR, "Esperado ')' após expressão");
        return new AST.Out(expr);
    }

    private AST.Bloco parseBloco() {
        List<AST.No> comandos = new ArrayList<>();
        while (!estaNoFinal() && !verificar(Tipo.FIM) && !verificar(Tipo.ELSE)) {
            AST.No cmd = parseDeclaracao();
            if (cmd != null) comandos.add(cmd);
        }
        return new AST.Bloco(comandos);
    }

    // ---------------- Utilitários ----------------

    private boolean estaNoFinal() {
        return olhar().getTipo() == Tipo.EOF;
    }

    private Token olhar() {
        return tokens.get(atual);
    }

    private Token avancar() {
        if (!estaNoFinal()) atual++;
        return anterior();
    }

    private Token anterior() {
        return tokens.get(atual - 1);
    }

    private boolean verificar(Tipo tipo) {
        if (estaNoFinal()) return false;
        return olhar().getTipo() == tipo;
    }

    private Token consumir(Tipo tipo, String mensagemErro) {
        if (verificar(tipo)) return avancar();
        reportarErro(mensagemErro);
        return new Token(Tipo.STRING, "", olhar().getLinha(), olhar().getColuna()); // placeholder
    }

    private void reportarErro(String msg) {
        erros.add(new ParserError(msg, olhar().getLinha(), olhar().getColuna()));
    }

    /** Recupera sincronizando até ponto seguro */
    private void sincronizar() {
        avancar();
        while (!estaNoFinal()) {
            if (anterior().getTipo() == Tipo.FIM) return;
            switch (olhar().getTipo()) {
                case INT: case BOOL: case IF: case LOOP: case OUT:
                    return;
            }
            avancar();
        }
    }

    /** Identifica tokens que podem iniciar uma expressão */
    private boolean ehInicioExpressao() {
        return verificar(Tipo.NUMERO) || verificar(Tipo.BOOLEANO) ||
               verificar(Tipo.STRING) || verificar(Tipo.IDENTIFICADOR) ||
               verificar(Tipo.ABRE_PAR) || verificar(Tipo.NEGACAO) ||
               verificar(Tipo.MENOS);
    }
}
