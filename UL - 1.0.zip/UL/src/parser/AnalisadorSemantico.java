package parser;

import lexer.Token;
import errors.SemanticError;
import java.util.*;

/**
 * Analisador Semântico da linguagem UL.
 * Verifica declarações, tipos e coerência de expressões,
 * registrando múltiplos erros sem interromper o fluxo.
 */
public class AnalisadorSemantico {

    // Tabela de símbolos: nome da variável → tipo ("int", "bool", "string")
    private final Map<String, String> tabela = new HashMap<>();

    // Lista de erros detectados (multi-erro)
    private final List<SemanticError> erros = new ArrayList<>();

    /** Retorna a lista de erros encontrados até o momento. */
    public List<SemanticError> getErros() {
        return erros;
    }

    /** Executa a análise semântica sobre um nó ou bloco completo. */
    public void analisar(AST.No no) {
        if (no == null) return;

        try {
            if (no instanceof AST.VarDecl) {
                analisarVarDecl((AST.VarDecl) no);
            } else if (no instanceof AST.Atribuicao) {
                analisarAtribuicao((AST.Atribuicao) no);
            } else if (no instanceof AST.If) {
                analisarIf((AST.If) no);
            } else if (no instanceof AST.Loop) {
                analisarLoop((AST.Loop) no);
            } else if (no instanceof AST.Out) {
                analisarOut((AST.Out) no);
            } else if (no instanceof AST.Bloco) {
                for (AST.No comando : ((AST.Bloco) no).comandos) {
                    analisar(comando);
                }
            }
        } catch (SemanticError e) {
            // Captura e armazena o erro, mas continua o processo
            erros.add(e);
        } catch (Exception e) {
            // Segurança: captura erros inesperados para depuração
            erros.add(new SemanticError("Erro inesperado em " + no.getClass().getSimpleName() + ": " + e.getMessage(), -1));
        }
    }

    // ---------------- Declarações ----------------

    private void analisarVarDecl(AST.VarDecl decl) {
        String nome = decl.identificador.getLexema();
        String tipo = decl.tipo.getLexema();

        if (tabela.containsKey(nome)) {
            erros.add(new SemanticError("Variável '" + nome + "' já declarada.", decl.identificador.getLinha()));
            return;
        }

        String tipoExpr = inferirTipo(decl.inicializador);
        if (!tipo.equals(tipoExpr)) {
            erros.add(new SemanticError("Tipo incompatível em '" + nome +
                    "': esperado " + tipo + ", encontrado " + tipoExpr, decl.identificador.getLinha()));
            return;
        }

        tabela.put(nome, tipo);
    }

    private void analisarAtribuicao(AST.Atribuicao atrib) {
        String nome = atrib.identificador.getLexema();

        if (!tabela.containsKey(nome)) {
            erros.add(new SemanticError("Variável '" + nome + "' não declarada.", atrib.identificador.getLinha()));
            return;
        }

        String tipoVar = tabela.get(nome);
        String tipoExpr = inferirTipo(atrib.valor);

        if (!tipoVar.equals(tipoExpr)) {
            erros.add(new SemanticError("Atribuição inválida em '" + nome +
                    "': esperado " + tipoVar + ", encontrado " + tipoExpr, atrib.identificador.getLinha()));
        }
    }

    // ---------------- Comandos de Controle ----------------

    private void analisarIf(AST.If cmd) {
        String tipoCond = inferirTipo(cmd.condicao);
        if (!tipoCond.equals("bool")) {
            erros.add(new SemanticError("Condição do if deve ser booleana.", getLinha(cmd.condicao)));
        }
        analisar(cmd.blocoThen);
        if (cmd.blocoElse != null) {
            analisar(cmd.blocoElse);
        }
    }

    private void analisarLoop(AST.Loop cmd) {
        String tipoCond = inferirTipo(cmd.condicao);
        if (!tipoCond.equals("bool")) {
            erros.add(new SemanticError("Condição do loop deve ser booleana.", getLinha(cmd.condicao)));
        }
        analisar(cmd.corpo);
    }

    private void analisarOut(AST.Out cmd) {
        inferirTipo(cmd.expressao); // aceita qualquer tipo
    }

    // ---------------- Inferência de Tipos ----------------

    private String inferirTipo(AST.No no) {
        if (no == null) return "indefinido";

        try {
            if (no instanceof AST.Literal) {
                Token t = ((AST.Literal) no).valor;
                switch (t.getTipo()) {
                    case NUMERO:   return "int";
                    case BOOLEANO: return "bool";
                    case STRING:   return "string";
                }
            } else if (no instanceof AST.Variavel) {
                String nome = ((AST.Variavel) no).nome.getLexema();
                if (!tabela.containsKey(nome)) {
                    erros.add(new SemanticError("Variável '" + nome + "' não declarada.", ((AST.Variavel) no).nome.getLinha()));
                    return "indefinido";
                }
                return tabela.get(nome);
            } else if (no instanceof AST.Binario) {
                String tipoEsq = inferirTipo(((AST.Binario) no).esquerda);
                String tipoDir = inferirTipo(((AST.Binario) no).direita);
                Token op = ((AST.Binario) no).operador;

                switch (op.getTipo()) {
                    case MAIS: case MENOS: case MULT: case DIV: case MOD:
                        if (!tipoEsq.equals("int") || !tipoDir.equals("int")) {
                            erros.add(new SemanticError("Operador '" + op.getLexema() +
                                    "' só pode ser usado com inteiros.", op.getLinha()));
                        }
                        return "int";

                    case IGUAL: case DIFERENTE: case MENOR: case MENOR_IGUAL:
                    case MAIOR: case MAIOR_IGUAL:
                        if (!tipoEsq.equals(tipoDir)) {
                            erros.add(new SemanticError("Comparação entre tipos diferentes: " +
                                    tipoEsq + " e " + tipoDir, op.getLinha()));
                        }
                        return "bool";

                    case E_LOGICO: case OU_LOGICO:
                        if (!tipoEsq.equals("bool") || !tipoDir.equals("bool")) {
                            erros.add(new SemanticError("Operador '" + op.getLexema() +
                                    "' só pode ser usado com booleanos.", op.getLinha()));
                        }
                        return "bool";
                }
            } else if (no instanceof AST.Unario) {
                String tipo = inferirTipo(((AST.Unario) no).direita);
                Token op = ((AST.Unario) no).operador;
                if (op.getTipo() == Token.Tipo.MENOS) {
                    if (!tipo.equals("int")) {
                        erros.add(new SemanticError("Operador '-' só pode ser usado com inteiros.", op.getLinha()));
                    }
                    return "int";
                } else if (op.getTipo() == Token.Tipo.NEGACAO) {
                    if (!tipo.equals("bool")) {
                        erros.add(new SemanticError("Operador '!' só pode ser usado com booleanos.", op.getLinha()));
                    }
                    return "bool";
                }
            }
        } catch (SemanticError e) {
            erros.add(e);
        } catch (Exception e) {
            erros.add(new SemanticError("Erro ao inferir tipo: " + e.getMessage(), getLinha(no)));
        }

        return "indefinido";
    }

    /** Retorna a linha associada ao nó, se possível. */
    private int getLinha(AST.No no) {
        if (no instanceof AST.Literal) return ((AST.Literal) no).valor.getLinha();
        if (no instanceof AST.Variavel) return ((AST.Variavel) no).nome.getLinha();
        return -1;
    }
}
