package lexer;

import java.util.ArrayList;
import java.util.List;
import errors.LexerError;

/**
 * Analisador Léxico da linguagem UL.
 * Responsável por converter o código-fonte em uma lista de tokens.
 */
public class Lexer {

    private final String codigo;
    private final List<Token> tokens = new ArrayList<>();
    private int inicio = 0;
    private int atual = 0;
    private int linha = 1;
    private int coluna = 1;

    public Lexer(String codigo) {
        this.codigo = codigo;
    }

    /** Ponto de entrada: retorna todos os tokens. */
    public List<Token> analisar() {
        while (!estaNoFinal()) {
            inicio = atual;
            escanearToken();
        }
        tokens.add(new Token(Token.Tipo.EOF, "", linha, coluna));
        return tokens;
    }

    // -------------------- Núcleo do lexer --------------------

    private void escanearToken() {
        char c = avancar();

        switch (c) {
            // ignora espaços, tabs e quebras de linha
            case ' ':
            case '\r':
            case '\t':
                break;
            case '\n':
                linha++;
                coluna = 1;
                break;

            // símbolos simples
            case '(':
                adicionar(Token.Tipo.ABRE_PAR);
                break;
            case ')':
                adicionar(Token.Tipo.FECHA_PAR);
                break;
            case ';':
                adicionar(Token.Tipo.PONTO_VIRGULA);
                break;
            case '=':
                adicionar(verificar('=') ? Token.Tipo.IGUAL : Token.Tipo.ATRIBUICAO);
                break;
            case '!':
                adicionar(verificar('=') ? Token.Tipo.DIFERENTE : Token.Tipo.NEGACAO);
                break;
            case '<':
                adicionar(verificar('=') ? Token.Tipo.MENOR_IGUAL : Token.Tipo.MENOR);
                break;
            case '>':
                adicionar(verificar('=') ? Token.Tipo.MAIOR_IGUAL : Token.Tipo.MAIOR);
                break;
            case '+':
                adicionar(Token.Tipo.MAIS);
                break;
            case '-':
                adicionar(Token.Tipo.MENOS);
                break;
            case '*':
                adicionar(Token.Tipo.MULT);
                break;
            case '/':
                if (verificar('/')) {
                    while (peek() != '\n' && !estaNoFinal()) avancar(); // comentário
                } else {
                    adicionar(Token.Tipo.DIV);
                }
                break;
            case '%':
                adicionar(Token.Tipo.MOD);
                break;
                
            case '.':
                if (ehDigito(peek())) {
                    numero();
                } else {
                    throw new LexerError("Caractere inesperado: '.'", linha, coluna);
                }
                break;

            case '&':
                if (verificar('&')) {
                    adicionar(Token.Tipo.E_LOGICO); // token para &&
                } else {
                    throw new LexerError("Caractere '&' isolado é inválido. Use '&&'.", linha, coluna);
                }
                break;

            case '|':
                if (verificar('|')) {
                    adicionar(Token.Tipo.OU_LOGICO); // token para ||
                } else {
                    throw new LexerError("Caractere '|' isolado é inválido. Use '||'.", linha, coluna);
                }
                break;

            // literais e identificadores
            default:
                if (ehDigito(c)) numero();
                else if (ehLetra(c)) identificador();
                else if (c == '"') string();
                else throw new LexerError("Caractere inesperado: '" + c + "'", linha, coluna);
                break;
        }
    }

    // -------------------- Regras de tokens --------------------

    private void numero() {
        boolean temDigitoAntes = ehDigito(codigo.charAt(inicio));
        boolean temPonto = false;

        // Lê a parte inteira (se houver)
        while (ehDigito(peek())) avancar();

        // Verifica se há parte decimal (ponto + dígitos)
        if (peek() == '.' && ehDigito(peekProximo())) {
            temPonto = true;
            avancar(); // consome '.'
            while (ehDigito(peek())) avancar();
        }

        String texto = codigo.substring(inicio, atual);

        // Caso comece com ponto, adiciona o zero à esquerda (".5" → "0.5")
        if (!temDigitoAntes && texto.startsWith(".")) {
            texto = "0" + texto;
        }

        // Adiciona o token
        if (temPonto) {
            tokens.add(new Token(Token.Tipo.FLOAT, texto, linha, coluna));
        } else {
            tokens.add(new Token(Token.Tipo.NUMERO, texto, linha, coluna));
        }
    }


    private void string() {
        while (peek() != '"' && !estaNoFinal()) {
            if (peek() == '\n') linha++;
            avancar();
        }

        if (estaNoFinal()) throw new LexerError("String não finalizada", linha, coluna);

        avancar(); // fecha aspas
        String valor = codigo.substring(inicio + 1, atual - 1);
        tokens.add(new Token(Token.Tipo.STRING, valor, linha, coluna));
    }

    private void identificador() {
        while (ehLetraOuDigito(peek())) avancar();
        String texto = codigo.substring(inicio, atual);
        Token.Tipo tipo = palavrasReservadas(texto);
        tokens.add(new Token(tipo, texto, linha, coluna));
    }

    private Token.Tipo palavrasReservadas(String texto) {
        return switch (texto) {
            case "int" -> Token.Tipo.INT;
            case "bool" -> Token.Tipo.BOOL;
            case "true", "false" -> Token.Tipo.BOOLEANO;
            case "if" -> Token.Tipo.IF;
            case "else" -> Token.Tipo.ELSE;
            case "loop" -> Token.Tipo.LOOP;
            case "out" -> Token.Tipo.OUT;
            case "fim" -> Token.Tipo.FIM;
            default -> Token.Tipo.IDENTIFICADOR;
        };
    }

    // -------------------- Utilitários --------------------

    private boolean estaNoFinal() {
        return atual >= codigo.length();
    }

    private char avancar() {
        coluna++;
        return codigo.charAt(atual++);
    }

    private boolean verificar(char esperado) {
        if (estaNoFinal() || codigo.charAt(atual) != esperado) return false;
        atual++;
        coluna++;
        return true;
    }

    private char peek() {
        if (estaNoFinal()) return '\0';
        return codigo.charAt(atual);
    }

    private char peekProximo() {
        if (atual + 1 >= codigo.length()) return '\0';
        return codigo.charAt(atual + 1);
    }

    private void adicionar(Token.Tipo tipo) {
        String lexema = codigo.substring(inicio, atual);
        tokens.add(new Token(tipo, lexema, linha, coluna));
    }

    private boolean ehDigito(char c) {
        return c >= '0' && c <= '9';
    }

    private boolean ehLetra(char c) {
        return Character.isLetter(c) || c == '_';
    }

    private boolean ehLetraOuDigito(char c) {
        return ehLetra(c) || ehDigito(c);
    }
}
