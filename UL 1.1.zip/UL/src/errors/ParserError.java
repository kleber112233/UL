package errors;

public class ParserError extends RuntimeException {
    private final String mensagem;
    private final int linha;
    private final int coluna;

    public ParserError(String mensagem, int linha, int coluna) {
        super(mensagem);
        this.mensagem = mensagem;
        this.linha = linha;
        this.coluna = coluna;
    }

    public String getMensagem() { return mensagem; }
    public int getLinha() { return linha; }
    public int getColuna() { return coluna; }

    @Override
    public String toString() {
        return String.format("Erro sintático na linha %d, coluna %d: %s", linha, coluna, mensagem);
    }
}
