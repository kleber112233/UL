package errors;

public class SemanticError {
    private final int linha;
    private final int coluna;
    private final String mensagem;

    public SemanticError(int linha, int coluna, String mensagem) {
        this.linha = linha;
        this.coluna = coluna;
        this.mensagem = mensagem;
    }

    public int getLinha() { return linha; }
    public int getColuna() { return coluna; }
    public String getMensagem() { return mensagem; }

    @Override
    public String toString() {
        return "Erro semântico na linha " + linha + ", coluna " + coluna + ": " + mensagem;
    }
}
