package errors;

public class LexerError {
    private final int linha;
    private final int coluna;
    private final String mensagem;

    public LexerError(int linha, int coluna, String mensagem) {
        this.linha = linha;
        this.coluna = coluna;
        this.mensagem = mensagem;
    }

    public int getLinha() { return linha; }
    public int getColuna() { return coluna; }
    public String getMensagem() { return mensagem; }

    @Override
    public String toString() {
        return "Erro léxico na linha " + linha + ", coluna " + coluna + ": " + mensagem;
    }
}
