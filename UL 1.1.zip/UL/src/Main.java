import lexer.*;
import parser.*;
import errors.*;
import java.util.*;
import interpreter.*;

/**
 *  Compilador UL - Pipeline Completo (Léxico → Sintático → Semântico → Execução)
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===  Compilador UL - Execução Completa ===\n");

        // ============================================================
        // === Código UL de teste
        // ============================================================
        String codigo = """
            // Declaração de variáveis inteiras e booleanas
            int a = 10
            int b = 5
            int c = 2
            bool maior = a > b
            bool menor = a < b
            bool igual = a == b
            bool diferente = a != b
            bool logico = (a > b && c < a) || (b == 5)

            // Impressões simples
            out(a)
            out(b)
            out(c)
            out(maior)
            out(menor)
            out(igual)
            out(diferente)
            out(logico)

            // Expressões aritméticas complexas com precedência e parênteses
            int resultado1 = a + b * c
            int resultado2 = (a + b) * c
            int resultado3 = a - b + c * (a / b)
            out(resultado1)
            out(resultado2)
            out(resultado3)

            // Condicional simples
            if (a > b)
                out(100)
            fim

            // Condicional com else
            if (a < b)
                out(200)
            else
                out(300)
            fim

            // Condicional aninhado
            if (a > 0)
                if (b > 0)
                    out(400)
                else
                    out(500)
                fim
            else
                out(600)
            fim

            // Uso de negação lógica
            bool inverso = !(a < b)
            out(inverso)

            // Loop básico
            int i = 0
            loop (i < 5)
                out(i)
                i = i + 1
            fim

            // Loop com operação interna
            int soma = 0
            int j = 1
            loop (j <= 5)
                soma = soma + j
                j = j + 1
            fim
            out(soma)

            // Condicional com lógica complexa
            if ((a > b && soma == 15) || (c == 3))
                out(999)
            else
                out(888)
            fim

            // Teste final com múltiplas operações
            int final = (a + b * c) - (soma / 3)
            if (a > b)
                final = final + 1
            fim
            out(final)
            out(final)
            """;

        System.out.println("===  Código Fonte ===");
        System.out.println(codigo);
        System.out.println("========================\n");

        // ============================================================
        // === 1️⃣ Etapa Léxica
        // ============================================================
        System.out.println("=== 🧩 Etapa Léxica ===");

        Lexer lexer = new Lexer(codigo);
        List<Token> tokens = lexer.analisar();
        List<LexerError> errosLexicos = lexer.getErros();

        if (!errosLexicos.isEmpty()) {
            System.out.println(" Foram encontrados " + errosLexicos.size() + " erros léxicos:\n");
            for (LexerError e : errosLexicos) {
                System.out.printf("   • Linha %d, Coluna %d → %s%n",
                        e.getLinha(), e.getColuna(), e.getMensagem());
            }
            System.out.println("\n  Interrompendo execução devido a erros léxicos.\n");
            return;
        } else {
            System.out.println("✅ " + tokens.size() + " tokens gerados com sucesso.\n");
        }

        // ============================================================
        // === 2️⃣ Etapa Sintática
        // ============================================================
        System.out.println("=== Etapa Sintática ===");

        Parser parser = new Parser(tokens);
        List<AST.No> arvore = parser.parsePrograma();
        List<ParserError> errosSintaticos = parser.getErros();

        if (!errosSintaticos.isEmpty()) {
            System.out.println("❌ Foram encontrados " + errosSintaticos.size() + " erros sintáticos:\n");
            for (ParserError e : errosSintaticos) {
                System.out.printf("   • Linha %d, Coluna %d → %s%n",
                        e.getLinha(), e.getColuna(), e.getMensagem());
            }
            System.out.println("\n  Interrompendo execução devido a erros sintáticos.\n");
            return;
        } else {
            System.out.println(" AST construída com sucesso.\n");
        }

        // ============================================================
        // === 3️⃣ Etapa Semântica
        // ============================================================
        System.out.println("=== Etapa Semântica ===");

        AnalisadorSemantico semantico = new AnalisadorSemantico();
        semantico.analisar(arvore);
        List<SemanticError> errosSemanticos = semantico.getErros();

        if (!errosSemanticos.isEmpty()) {
            System.out.println("❌ Foram encontrados " + errosSemanticos.size() + " erros semânticos:\n");
            for (SemanticError e : errosSemanticos) {
                System.out.printf("   • Linha %d, Coluna %d → %s%n",
                        e.getLinha(), e.getColuna(), e.getMensagem());
            }
            System.out.println("\n⚠️  Interrompendo execução devido a erros semânticos.\n");
            return;
        } else {
            System.out.println("✅ Nenhum erro semântico encontrado. Programa válido!\n");
        }

        // ============================================================
        // === 4️⃣ Etapa de Execução / Interpretação
        // ============================================================
        System.out.println("=== Resultado de Execução ===");

        try {
            Interpreter interpretador = new Interpreter();
            for (AST.No no : arvore) {
                interpretador.executar(no);
            }
            System.out.println("\n✅ Execução concluída com sucesso!\n");
        } catch (Exception e) {
            System.out.println("❌ Erro durante a execução: " + e.getMessage());
        }

        System.out.println("=== ✅ Pipeline Finalizado ===\n");

        // ============================================================
        // === 🧾 Saída esperada do programa de teste
        // ============================================================

    }
}
