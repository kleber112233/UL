package lexer;

/**
 * Representa um token identificado no código-fonte.
 */
public class Token {

    /**
     * Tipos de tokens da linguagem UL.
     */
    public enum Tipo {
        // literais
        NUMERO, FLOAT, BOOLEANO, STRING, IDENTIFICADOR,

        // tipos básicos
        INT, BOOL,

        // operadores aritméticos
        MAIS, MENOS, MULT, DIV, MOD,

        // operadores relacionais
        MENOR, MENOR_IGUAL, MAIOR, MAIOR_IGUAL,

        // operadores de igualdade
        IGUAL, DIFERENTE,

        // operadores lógicos
        E_LOGICO, OU_LOGICO, NEGACAO,

        // atribuição
        ATRIBUICAO,

        // símbolos
        ABRE_PAR, FECHA_PAR, PONTO_VIRGULA,

        // palavras-chave
        IF, ELSE, LOOP, OUT, FIM,

        // separador de comandos por linha
        QUEBRA_LINHA,

        // fim de arquivo
        EOF
    }

    private final Tipo tipo;      // Categoria do token
    private final String lexema;  // Texto original
    private final int linha;      // Linha onde aparece
    private final int coluna;     // Coluna inicial

    public Token(Tipo tipo, String lexema, int linha, int coluna) {
        this.tipo = tipo;
        this.lexema = lexema;
        this.linha = linha;
        this.coluna = coluna;
    }

    public Tipo getTipo() { return tipo; }
    public String getLexema() { return lexema; }
    public int getLinha() { return linha; }
    public int getColuna() { return coluna; }

    @Override
    public String toString() {
        return String.format("Token[%s, '%s', linha=%d, coluna=%d]",
                tipo, lexema, linha, coluna);
    }
}
