package lexer;

import errors.LexerError;
import java.util.*;
import java.util.regex.*;

/**
 * Analisador Léxico da linguagem UL.
 * Gera tokens conforme padrões definidos e acumula erros léxicos.
 */
public class Lexer {
    private final String codigo;
    private final List<Token> tokens = new ArrayList<>();
    private final List<LexerError> erros = new ArrayList<>();

    private int linha = 1;
    private int coluna = 1;
    private int indice = 0;

    private static class Regra {
        final Pattern padrao;
        final Token.Tipo tipo;
        final boolean ignorar;

        Regra(String regex, Token.Tipo tipo, boolean ignorar) {
            this.padrao = Pattern.compile("^" + regex);
            this.tipo = tipo;
            this.ignorar = ignorar;
        }
    }

    private final List<Regra> regras = new ArrayList<>();

    public Lexer(String codigo) {
        this.codigo = codigo;

        // Comentários
        regras.add(new Regra("//.*", null, true));

        // Espaços/tabulações ignorados; \n vira token
        regras.add(new Regra("[ \\t\\r]+", null, true));
        regras.add(new Regra("\\n+", Token.Tipo.QUEBRA_LINHA, false));

        // Literais
        regras.add(new Regra("\\d+\\.\\d+", Token.Tipo.FLOAT, false));
        regras.add(new Regra("\\d+", Token.Tipo.NUMERO, false));
        regras.add(new Regra("\"[^\"]*\"", Token.Tipo.STRING, false));
        regras.add(new Regra("true|false", Token.Tipo.BOOLEANO, false));

        // Palavras-chave
        regras.add(new Regra("int", Token.Tipo.INT, false));
        regras.add(new Regra("bool", Token.Tipo.BOOL, false));
        regras.add(new Regra("if", Token.Tipo.IF, false));
        regras.add(new Regra("else", Token.Tipo.ELSE, false));
        regras.add(new Regra("loop", Token.Tipo.LOOP, false));
        regras.add(new Regra("out", Token.Tipo.OUT, false));
        regras.add(new Regra("fim", Token.Tipo.FIM, false));

        // Operadores compostos
        regras.add(new Regra("==", Token.Tipo.IGUAL, false));
        regras.add(new Regra("!=", Token.Tipo.DIFERENTE, false));
        regras.add(new Regra("<=", Token.Tipo.MENOR_IGUAL, false));
        regras.add(new Regra(">=", Token.Tipo.MAIOR_IGUAL, false));
        regras.add(new Regra("&&", Token.Tipo.E_LOGICO, false));
        regras.add(new Regra("\\|\\|", Token.Tipo.OU_LOGICO, false));

        // Operadores simples
        regras.add(new Regra("!", Token.Tipo.NEGACAO, false));
        regras.add(new Regra("=", Token.Tipo.ATRIBUICAO, false));
        regras.add(new Regra("\\+", Token.Tipo.MAIS, false));
        regras.add(new Regra("-", Token.Tipo.MENOS, false));
        regras.add(new Regra("\\*", Token.Tipo.MULT, false));
        regras.add(new Regra("/", Token.Tipo.DIV, false));
        regras.add(new Regra("%", Token.Tipo.MOD, false));
        regras.add(new Regra("<", Token.Tipo.MENOR, false));
        regras.add(new Regra(">", Token.Tipo.MAIOR, false));

        // Símbolos
        regras.add(new Regra("\\(", Token.Tipo.ABRE_PAR, false));
        regras.add(new Regra("\\)", Token.Tipo.FECHA_PAR, false));
        regras.add(new Regra(";", Token.Tipo.PONTO_VIRGULA, false));

        // Identificadores
        regras.add(new Regra("[a-zA-Z_][a-zA-Z0-9_]*", Token.Tipo.IDENTIFICADOR, false));
    }

    public List<Token> getTokens() { return tokens; }
    public List<LexerError> getErros() { return erros; }

    public List<Token> analisar() {
        while (indice < codigo.length()) {
            String resto = codigo.substring(indice);
            boolean encontrou = false;

            for (Regra r : regras) {
                Matcher m = r.padrao.matcher(resto);
                if (m.find()) {
                    String lexema = m.group();
                    int inicioColuna = coluna;
                    indice += lexema.length();
                    coluna += lexema.length();

                    if (r.tipo == Token.Tipo.QUEBRA_LINHA) {
                        // múltiplos \n contam várias linhas
                        for (int i = 0; i < lexema.length(); i++) {
                            if (lexema.charAt(i) == '\n') { linha++; coluna = 1; }
                        }
                    }

                    if (!r.ignorar && r.tipo != null) {
                        tokens.add(new Token(r.tipo, lexema, linha, inicioColuna));
                    }

                    encontrou = true;
                    break;
                }
            }

            if (!encontrou) {
                char c = codigo.charAt(indice);
                erros.add(new LexerError(linha, coluna, "Caractere inesperado: '" + c + "'"));
                indice++;
                coluna++;
            }
        }

        tokens.add(new Token(Token.Tipo.EOF, "", linha, coluna));
        return tokens;
    }
}
