package parser;

import lexer.Token;
import errors.ParserError;
import java.util.*;

/**
 * Parser.
 * Aceita quebras de linha como separadores de comandos (opcionalmente ';').
 */
public class Parser {
    private final List<Token> tokens;
    private int atual = 0;
    private final List<ParserError> erros = new ArrayList<>();

    public Parser(List<Token> tokens) { this.tokens = tokens; }
    public List<ParserError> getErros() { return erros; }

    public List<AST.No> parsePrograma() {
        List<AST.No> comandos = new ArrayList<>();
        ignorarQuebras();
        while (!estaNoFinal() && !verificar(Token.Tipo.FIM)) {
            try {
                AST.No no = declaracaoOuComando();
                if (no != null) comandos.add(no);
                ignorarQuebras();
            } catch (ParserError e) {
                erros.add(e);
                sincronizar();
            }
        }
        // consome 'fim' do programa, se houver
        if (verificar(Token.Tipo.FIM)) avancar();
        return comandos;
    }

    private void ignorarQuebras() {
        while (verificar(Token.Tipo.QUEBRA_LINHA) || verificar(Token.Tipo.PONTO_VIRGULA)) avancar();
    }

    // === Declarações e Comandos ===

    private AST.No declaracaoOuComando() {
        if (verificar(Token.Tipo.INT) || verificar(Token.Tipo.BOOL)) return declaracao();
        return comando();
    }

    private AST.No declaracao() {
        Token tipo = avancar();
        Token id = consumir(Token.Tipo.IDENTIFICADOR, "Esperado identificador após tipo.");
        consumir(Token.Tipo.ATRIBUICAO, "Esperado '=' após identificador.");
        AST.No valor = expressao();
        ignorarQuebras();
        return new AST.VarDecl(tipo, id, valor);
    }

    private AST.No comando() {
        if (verificar(Token.Tipo.IF))   return comandoIf();
        if (verificar(Token.Tipo.LOOP)) return comandoLoop();
        if (verificar(Token.Tipo.OUT))  return comandoOut();
        if (verificar(Token.Tipo.IDENTIFICADOR)) return atribuicao();

        Token t = atual();
        erros.add(new ParserError("Comando inválido.", t.getLinha(), t.getColuna()));
        if (!estaNoFinal()) avancar();
        ignorarQuebras();
        return null;
    }

    private AST.No comandoIf() {
        consumir(Token.Tipo.IF, "Esperado 'if'.");
        consumir(Token.Tipo.ABRE_PAR, "Esperado '(' após 'if'.");
        AST.No cond = expressao();
        consumir(Token.Tipo.FECHA_PAR, "Esperado ')' após condição.");
        AST.Bloco blocoThen = blocoComandos();
        AST.Bloco blocoElse = null;
        if (verificar(Token.Tipo.ELSE)) {
            avancar();
            blocoElse = blocoComandos();
        }
        consumir(Token.Tipo.FIM, "Esperado 'fim' após bloco do if.");
        ignorarQuebras();
        return new AST.If(cond, blocoThen, blocoElse);
    }

    private AST.No comandoLoop() {
        consumir(Token.Tipo.LOOP, "Esperado 'loop'.");
        consumir(Token.Tipo.ABRE_PAR, "Esperado '(' após 'loop'.");
        AST.No cond = expressao();
        consumir(Token.Tipo.FECHA_PAR, "Esperado ')' após condição.");
        AST.Bloco corpo = blocoComandos();
        consumir(Token.Tipo.FIM, "Esperado 'fim' após corpo do loop.");
        ignorarQuebras();
        return new AST.Loop(cond, corpo);
    }

    private AST.Bloco blocoComandos() {
        List<AST.No> comandos = new ArrayList<>();
        ignorarQuebras();
        while (!estaNoFinal() && !verificar(Token.Tipo.FIM) && !verificar(Token.Tipo.ELSE)) {
            AST.No cmd = declaracaoOuComando();
            if (cmd != null) comandos.add(cmd);
            ignorarQuebras();
        }
        return new AST.Bloco(comandos);
    }

    private AST.No comandoOut() {
        consumir(Token.Tipo.OUT, "Esperado 'out'.");
        consumir(Token.Tipo.ABRE_PAR, "Esperado '(' após 'out'.");
        AST.No valor = expressao();
        consumir(Token.Tipo.FECHA_PAR, "Esperado ')' após expressão.");
        ignorarQuebras();
        return new AST.Out(valor);
    }

    private AST.No atribuicao() {
        Token id = avancar();
        consumir(Token.Tipo.ATRIBUICAO, "Esperado '=' após identificador.");
        AST.No valor = expressao();
        ignorarQuebras();
        return new AST.Atribuicao(id, valor);
    }

    // === Expressões ===

    private AST.No expressao() { return logicoOu(); }

    private AST.No logicoOu() {
        AST.No expr = logicoE();
        while (verificar(Token.Tipo.OU_LOGICO)) {
            Token op = avancar();
            AST.No dir = logicoE();
            expr = new AST.Binario(expr, op, dir);
        }
        return expr;
    }

    private AST.No logicoE() {
        AST.No expr = igualdade();
        while (verificar(Token.Tipo.E_LOGICO)) {
            Token op = avancar();
            AST.No dir = igualdade();
            expr = new AST.Binario(expr, op, dir);
        }
        return expr;
    }

    private AST.No igualdade() {
        AST.No expr = comparacao();
        while (verificar(Token.Tipo.IGUAL) || verificar(Token.Tipo.DIFERENTE)) {
            Token op = avancar();
            AST.No dir = comparacao();
            expr = new AST.Binario(expr, op, dir);
        }
        return expr;
    }

    private AST.No comparacao() {
        AST.No expr = termo();
        while (verificar(Token.Tipo.MAIOR) || verificar(Token.Tipo.MENOR)
                || verificar(Token.Tipo.MAIOR_IGUAL) || verificar(Token.Tipo.MENOR_IGUAL)) {
            Token op = avancar();
            AST.No dir = termo();
            expr = new AST.Binario(expr, op, dir);
        }
        return expr;
    }

    private AST.No termo() {
        AST.No expr = fator();
        while (verificar(Token.Tipo.MAIS) || verificar(Token.Tipo.MENOS)) {
            Token op = avancar();
            AST.No dir = fator();
            expr = new AST.Binario(expr, op, dir);
        }
        return expr;
    }

    private AST.No fator() {
        AST.No expr = unario();
        while (verificar(Token.Tipo.MULT) || verificar(Token.Tipo.DIV) || verificar(Token.Tipo.MOD)) {
            Token op = avancar();
            AST.No dir = unario();
            expr = new AST.Binario(expr, op, dir);
        }
        return expr;
    }

    private AST.No unario() {
        if (verificar(Token.Tipo.NEGACAO) || verificar(Token.Tipo.MENOS)) {
            Token op = avancar();
            AST.No dir = unario();
            return new AST.Unario(op, dir);
        }
        return primario();
    }

    private AST.No primario() {
        if (verificar(Token.Tipo.NUMERO) || verificar(Token.Tipo.FLOAT)
                || verificar(Token.Tipo.BOOLEANO) || verificar(Token.Tipo.STRING))
            return new AST.Literal(avancar());

        if (verificar(Token.Tipo.IDENTIFICADOR))
            return new AST.Variavel(avancar());

        if (verificar(Token.Tipo.ABRE_PAR)) {
            avancar();
            AST.No expr = expressao();
            consumir(Token.Tipo.FECHA_PAR, "Esperado ')' após expressão.");
            return expr;
        }

        Token t = atual();
        erros.add(new ParserError("Expressão inválida.", t.getLinha(), t.getColuna()));
        if (!estaNoFinal()) avancar();
        return null;
    }

    // === Utilitários ===

    private Token avancar() {
        if (!estaNoFinal()) atual++;
        return anterior();
    }

    private Token atual() { return tokens.get(atual); }

    private Token anterior() { return tokens.get(Math.max(0, atual - 1)); }

    private boolean estaNoFinal() {
        return atual >= tokens.size() || atual().getTipo() == Token.Tipo.EOF;
    }

    private boolean verificar(Token.Tipo tipo) {
        if (estaNoFinal()) return false;
        return atual().getTipo() == tipo;
    }

    private Token consumir(Token.Tipo tipo, String msg) {
        if (verificar(tipo)) return avancar();
        Token t = atual();
        throw new ParserError(msg, t.getLinha(), t.getColuna());
    }

    private void sincronizar() {
        if (atual == 0) return;
        while (!estaNoFinal()) {
            if (anterior().getTipo() == Token.Tipo.FIM) return;
            switch (atual().getTipo()) {
                case INT: case BOOL: case IF: case LOOP: case OUT:
                    return;
            }
            avancar();
        }
    }
}
