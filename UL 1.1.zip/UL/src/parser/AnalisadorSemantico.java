package parser;

import lexer.Token;
import errors.SemanticError;
import java.util.*;

/**
 * Analisador Semântico da linguagem UL.
 * Verifica tipos, escopo e coerência das expressões.
 */
public class AnalisadorSemantico {
    private final List<SemanticError> erros = new ArrayList<>();
    private final Map<String, String> tabela = new HashMap<>();

    public List<SemanticError> getErros() { return erros; }

    public void analisar(List<AST.No> nos) {
        for (AST.No no : nos) analisarNo(no);
    }

    private void analisarNo(AST.No no) {
        if (no == null) return;
        if (no instanceof AST.VarDecl v) analisarDeclaracao(v);
        else if (no instanceof AST.Atribuicao a) analisarAtribuicao(a);
        else if (no instanceof AST.If i) analisarIf(i);
        else if (no instanceof AST.Loop l) analisarLoop(l);
        else if (no instanceof AST.Out o) inferirTipo(o.expressao);
        else if (no instanceof AST.Bloco b)
            for (AST.No c : b.comandos) analisarNo(c);
    }

    // === Declarações ===
    private void analisarDeclaracao(AST.VarDecl v) {
        String nome = v.identificador.getLexema();
        String tipo = v.tipo.getLexema();

        if (tabela.containsKey(nome)) {
            erros.add(new SemanticError(v.identificador.getLinha(), v.identificador.getColuna(),
                    "Variável '" + nome + "' já declarada."));
            return;
        }

        String tipoValor = inferirTipo(v.valor);
        if (tipoValor != null && !tipoCompativel(tipo, tipoValor)) {
            erros.add(new SemanticError(v.tipo.getLinha(), v.tipo.getColuna(),
                    "Tipo incompatível: esperado " + tipo + ", encontrado " + tipoValor + "."));
        }

        tabela.put(nome, tipo);
    }

    // === Atribuições ===
    private void analisarAtribuicao(AST.Atribuicao a) {
        String nome = a.identificador.getLexema();
        if (!tabela.containsKey(nome)) {
            erros.add(new SemanticError(a.identificador.getLinha(), a.identificador.getColuna(),
                    "Variável '" + nome + "' não declarada."));
            return;
        }

        String tipoVar = tabela.get(nome);
        String tipoValor = inferirTipo(a.valor);

        if (tipoValor != null && !tipoCompativel(tipoVar, tipoValor)) {
            erros.add(new SemanticError(a.identificador.getLinha(), a.identificador.getColuna(),
                    "Atribuição inválida: esperado " + tipoVar + ", encontrado " + tipoValor + "."));
        }
    }

    // === IF ===
    private void analisarIf(AST.If i) {
        String tipoCond = inferirTipo(i.condicao);
        if (!"bool".equals(tipoCond)) {
            erros.add(new SemanticError(linhaDe(i.condicao), colunaDe(i.condicao),
                    "Condição do 'if' deve ser booleana."));
        }
        analisarNo(i.thenBloco);
        if (i.elseBloco != null) analisarNo(i.elseBloco);
    }

    // === LOOP ===
    private void analisarLoop(AST.Loop l) {
        String tipoCond = inferirTipo(l.condicao);
        if (!"bool".equals(tipoCond)) {
            erros.add(new SemanticError(linhaDe(l.condicao), colunaDe(l.condicao),
                    "Condição do 'loop' deve ser booleana."));
        }
        analisarNo(l.corpo);
    }

    // === Inferência de tipos ===
    private String inferirTipo(AST.No no) {
        if (no == null) return null;

        if (no instanceof AST.Literal lit) {
            return switch (lit.token.getTipo()) {
                case NUMERO -> "int";
                case FLOAT -> "float";
                case BOOLEANO -> "bool";
                case STRING -> "string";
                default -> null;
            };
        }

        if (no instanceof AST.Variavel v) {
            String nome = v.token.getLexema();
            if (!tabela.containsKey(nome)) {
                erros.add(new SemanticError(v.token.getLinha(), v.token.getColuna(),
                        "Variável '" + nome + "' não declarada."));
                return null;
            }
            return tabela.get(nome);
        }

        if (no instanceof AST.Binario b) {
            String te = inferirTipo(b.esquerda);
            String td = inferirTipo(b.direita);
            if (te == null || td == null) return null;

            Token op = b.operador;
            switch (op.getTipo()) {
                case E_LOGICO, OU_LOGICO -> {
                    if (!"bool".equals(te) || !"bool".equals(td))
                        erros.add(new SemanticError(op.getLinha(), op.getColuna(),
                                "Operador lógico '" + op.getLexema() + "' requer booleanos."));
                    return "bool";
                }
                case MAIOR, MENOR, MAIOR_IGUAL, MENOR_IGUAL -> {
                    if (!ehNumerico(te) || !ehNumerico(td))
                        erros.add(new SemanticError(op.getLinha(), op.getColuna(),
                                "Operador relacional '" + op.getLexema() + "' requer numéricos."));
                    return "bool";
                }
                case IGUAL, DIFERENTE -> {
                    if (!te.equals(td))
                        erros.add(new SemanticError(op.getLinha(), op.getColuna(),
                                "Comparação entre tipos incompatíveis: " + te + " e " + td + "."));
                    return "bool";
                }
                case MAIS, MENOS, MULT, DIV, MOD -> {
                    if (!ehNumerico(te) || !ehNumerico(td))
                        erros.add(new SemanticError(op.getLinha(), op.getColuna(),
                                "Operador '" + op.getLexema() + "' requer números."));
                    return ("float".equals(te) || "float".equals(td)) ? "float" : "int";
                }
            }
        }

        if (no instanceof AST.Unario u) {
            String tipo = inferirTipo(u.operando);
            Token op = u.operador;

            if (op.getTipo() == Token.Tipo.NEGACAO && !"bool".equals(tipo))
                erros.add(new SemanticError(op.getLinha(), op.getColuna(),
                        "Operador '!' requer bool."));
            if (op.getTipo() == Token.Tipo.MENOS && !ehNumerico(tipo))
                erros.add(new SemanticError(op.getLinha(), op.getColuna(),
                        "Operador '-' requer numérico."));
            return tipo;
        }

        return null;
    }

    // === Utilitários ===
    private boolean ehNumerico(String t) { return "int".equals(t) || "float".equals(t); }

    private boolean tipoCompativel(String esperado, String encontrado) {
        return esperado.equals(encontrado) || ("float".equals(esperado) && "int".equals(encontrado));
    }

    private int linhaDe(AST.No no) {
        if (no instanceof AST.Literal l) return l.token.getLinha();
        if (no instanceof AST.Variavel v) return v.token.getLinha();
        if (no instanceof AST.Binario b) return b.operador.getLinha();
        if (no instanceof AST.Unario u) return u.operador.getLinha();
        return -1;
    }

    private int colunaDe(AST.No no) {
        if (no instanceof AST.Literal l) return l.token.getColuna();
        if (no instanceof AST.Variavel v) return v.token.getColuna();
        if (no instanceof AST.Binario b) return b.operador.getColuna();
        if (no instanceof AST.Unario u) return u.operador.getColuna();
        return -1;
    }
}
