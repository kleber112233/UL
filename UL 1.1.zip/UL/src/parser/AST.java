package parser;

import lexer.Token;
import java.util.List;

/**
 * Representação da Árvore Sintática Abstrata (AST) da linguagem UL.
 */
public class AST {

    public static abstract class No {}

    // === Declarações e Atribuições ===

    public static class VarDecl extends No {
        public final Token tipo;
        public final Token identificador;
        public final No valor;
        public VarDecl(Token tipo, Token identificador, No valor) {
            this.tipo = tipo; this.identificador = identificador; this.valor = valor;
        }
        @Override public String toString() {
            return "VarDecl(" + tipo.getLexema() + " " + identificador.getLexema() + " = " + valor + ")";
        }
    }

    public static class Atribuicao extends No {
        public final Token identificador;
        public final No valor;
        public Atribuicao(Token identificador, No valor) {
            this.identificador = identificador; this.valor = valor;
        }
        @Override public String toString() {
            return "Atribuicao(" + identificador.getLexema() + " = " + valor + ")";
        }
    }

    // === Expressões ===

    public static class Literal extends No {
        public final Token token;
        public Literal(Token token) { this.token = token; }
        @Override public String toString() { return "Literal(" + token.getLexema() + ")"; }
    }

    public static class Variavel extends No {
        public final Token token;
        public Variavel(Token token) { this.token = token; }
        @Override public String toString() { return "Variavel(" + token.getLexema() + ")"; }
    }

    public static class Binario extends No {
        public final No esquerda;
        public final Token operador;
        public final No direita;
        public Binario(No esquerda, Token operador, No direita) {
            this.esquerda = esquerda; this.operador = operador; this.direita = direita;
        }
        @Override public String toString() { return "Binario(" + esquerda + " " + operador.getLexema() + " " + direita + ")"; }
    }

    public static class Unario extends No {
        public final Token operador;
        public final No operando;
        public Unario(Token operador, No operando) {
            this.operador = operador; this.operando = operando;
        }
        @Override public String toString() { return "Unario(" + operador.getLexema() + " " + operando + ")"; }
    }

    public static class Expressao extends No {
        public final No expr;
        public Expressao(No expr) { this.expr = expr; }
        @Override public String toString() { return "Expr(" + expr + ")"; }
    }

    // === Controle ===

    public static class If extends No {
        public final No condicao;
        public final Bloco thenBloco;
        public final Bloco elseBloco;
        public If(No condicao, Bloco thenBloco, Bloco elseBloco) {
            this.condicao = condicao; this.thenBloco = thenBloco; this.elseBloco = elseBloco;
        }
        @Override public String toString() { return "If(cond=" + condicao + ", then=" + thenBloco + (elseBloco!=null? ", else=" + elseBloco : "") + ")"; }
    }

    public static class Loop extends No {
        public final No condicao;
        public final Bloco corpo;
        public Loop(No condicao, Bloco corpo) { this.condicao = condicao; this.corpo = corpo; }
        @Override public String toString() { return "Loop(cond=" + condicao + ", corpo=" + corpo + ")"; }
    }

    public static class Out extends No {
        public final No expressao;
        public Out(No expressao) { this.expressao = expressao; }
        @Override public String toString() { return "Out(" + expressao + ")"; }
    }

    public static class Bloco extends No {
        public final List<No> comandos;
        public Bloco(List<No> comandos) { this.comandos = comandos; }
        @Override public String toString() { return "Bloco" + comandos; }
    }
}
