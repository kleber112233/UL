package interpreter;

import parser.AST;
import lexer.Token;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

/**
 * Interpretador da linguagem UL.
 * Executa a AST gerada pelo parser.
 */
public class Interpreter {

    private final Map<String, Object> memoria = new HashMap<>();

    public void executarPrograma(List<AST.No> nos) {
        for (AST.No no : nos) executar(no);
    }

    public void executar(AST.No no) {
        if (no instanceof AST.VarDecl decl) {
            Object valor = avaliar(decl.valor);
            memoria.put(decl.identificador.getLexema(), valor);
        } else if (no instanceof AST.Atribuicao atrib) {
            Object valor = avaliar(atrib.valor);
            memoria.put(atrib.identificador.getLexema(), valor);
        } else if (no instanceof AST.If cmd) {
            boolean cond = asBool(avaliar(cmd.condicao));
            if (cond) executar(cmd.thenBloco);
            else if (cmd.elseBloco != null) executar(cmd.elseBloco);
        } else if (no instanceof AST.Loop cmd) {
            while (asBool(avaliar(cmd.condicao))) executar(cmd.corpo);
        } else if (no instanceof AST.Out cmd) {
            Object v = avaliar(cmd.expressao);
            System.out.println(v);
        } else if (no instanceof AST.Bloco bloco) {
            for (AST.No c : bloco.comandos) executar(c);
        }
    }

    // ============================================================
    // === AVALIAÇÃO DE EXPRESSÕES
    // ============================================================

    private Object avaliar(AST.No no) {
        if (no instanceof AST.Literal lit) {
            Token t = lit.token;
            return switch (t.getTipo()) {
                case NUMERO -> Integer.parseInt(t.getLexema());
                case FLOAT -> Double.parseDouble(t.getLexema());
                case BOOLEANO -> Boolean.parseBoolean(t.getLexema());
                case STRING -> stripQuotes(t.getLexema());
                default -> null;
            };
        }

        if (no instanceof AST.Variavel v) {
            String nome = v.token.getLexema();
            if (!memoria.containsKey(nome))
                throw new RuntimeException("Variável '" + nome + "' não declarada em tempo de execução.");
            return memoria.get(nome);
        }

        if (no instanceof AST.Unario u) {
            Object valor = avaliar(u.operando);
            Token op = u.operador;
            return switch (op.getTipo()) {
                case MENOS -> negate(valor);
                case NEGACAO -> !asBool(valor);
                default -> null;
            };
        }

        if (no instanceof AST.Binario b) {
            Object esq = avaliar(b.esquerda);
            Object dir = avaliar(b.direita);
            Token op = b.operador;

            return switch (op.getTipo()) {
                case MAIS -> add(esq, dir);
                case MENOS -> sub(esq, dir);
                case MULT -> mul(esq, dir);
                case DIV -> div(esq, dir);
                case MOD -> mod(esq, dir);

                case MAIOR -> toDouble(esq) > toDouble(dir);
                case MAIOR_IGUAL -> toDouble(esq) >= toDouble(dir);
                case MENOR -> toDouble(esq) < toDouble(dir);
                case MENOR_IGUAL -> toDouble(esq) <= toDouble(dir);

                case IGUAL -> esq == null ? dir == null : esq.equals(dir);
                case DIFERENTE -> esq == null ? dir != null : !esq.equals(dir);

                case E_LOGICO -> asBool(esq) && asBool(dir);
                case OU_LOGICO -> asBool(esq) || asBool(dir);
                default -> null;
            };
        }

        return null;
    }

    // ============================================================
    // === AUXILIARES
    // ============================================================

    private String stripQuotes(String s) {
        if (s == null) return null;
        if (s.startsWith("\"") && s.endsWith("\"")) return s.substring(1, s.length() - 1);
        return s;
    }

    private boolean asBool(Object v) {
        if (v instanceof Boolean b) return b;
        throw new RuntimeException("Valor não booleano em operação lógica: " + v);
    }

    private double toDouble(Object v) {
        if (v instanceof Integer i) return i.doubleValue();
        if (v instanceof Double d) return d;
        throw new RuntimeException("Valor não numérico em operação aritmética: " + v);
    }

    private Object add(Object a, Object b) {
        if (a instanceof String || b instanceof String)
            return String.valueOf(a) + String.valueOf(b);
        if (a instanceof Double || b instanceof Double)
            return toDouble(a) + toDouble(b);
        return ((Integer) a) + ((Integer) b);
    }

    private Object sub(Object a, Object b) {
        if (a instanceof Double || b instanceof Double)
            return toDouble(a) - toDouble(b);
        return ((Integer) a) - ((Integer) b);
    }

    private Object mul(Object a, Object b) {
        if (a instanceof Double || b instanceof Double)
            return toDouble(a) * toDouble(b);
        return ((Integer) a) * ((Integer) b);
    }

    private Object div(Object a, Object b) {
        double d = toDouble(b);
        if (d == 0.0) throw new RuntimeException("Divisão por zero.");
        if (a instanceof Integer && b instanceof Integer)
            return ((Integer) a) / ((Integer) b);
        return toDouble(a) / d;
    }

    private Object mod(Object a, Object b) {
        if (!(a instanceof Integer) || !(b instanceof Integer))
            throw new RuntimeException("Módulo (%) requer inteiros.");
        int divisor = (Integer) b;
        if (divisor == 0) throw new RuntimeException("Módulo por zero.");
        return ((Integer) a) % divisor;
    }

    private Object negate(Object v) {
        if (v instanceof Integer i) return -i;
        if (v instanceof Double d) return -d;
        throw new RuntimeException("Operador '-' requer operando numérico.");
    }
}
