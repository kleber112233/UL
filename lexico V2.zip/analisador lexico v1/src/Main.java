import lexer.Lexer;
import lexer.Token;
import parser.Parser;
import errors.LexerError;
import errors.ParserError;

import java.util.List;

/**
 * Classe principal do compilador UL.
 * Responsável por coordenar as fases de análise léxica e sintática.
 */
public class Main {

    public static void main(String[] args) {
        // Código-fonte de exemplo
        String codigo = """
            // --- DECLARAÇÕES ---
            int x = 10
            bool ativo = true
            int y = 3.14
            int z = .5

            // --- STRINGS ---
            out("Hello, UL!")
            out("String com quebra
            de linha") // deve dar erro

            // --- OPERADORES ---
            x = x + 1
            y = y - 2 * 3 / 4 % 2
            ativo = false
            bool b = (x > 5) && (y <= 2) || !ativo
            bool c = (x == y) != ativo

            // --- COMANDOS ---
            if (x > 0)
                out(x)
            else
                out(0)
            fim

            loop (x < 5)
                x = x + 1
            fim

            /* comentário de bloco
               que deve ser ignorado */
        """;

        try {
            // Fase 1: Léxico
            Lexer lexer = new Lexer(codigo);
            List<Token> tokens = lexer.analisar();

            System.out.println("\n=== 🧩 TOKENS GERADOS ===\n");
            int linhaAtual = -1;
            for (Token t : tokens) {
                if (t.getLinha() != linhaAtual) {
                    if (linhaAtual != -1) System.out.println();
                    linhaAtual = t.getLinha();
                    System.out.println("Linha " + linhaAtual + ":");
                }
                System.out.println("   " + t);
            }

            // Fase 2: Sintático
            Parser parser = new Parser(tokens);
            parser.parse();

            System.out.println("\n✅ Análise concluída com sucesso — sem erros léxicos ou sintáticos.");

        } catch (LexerError e) {
            System.out.println("\n❌ ERRO LÉXICO DETECTADO:");
            System.out.println("   " + e.getMessage());
        } catch (ParserError e) {
            System.out.println("\n❌ ERRO SINTÁTICO DETECTADO:");
            System.out.println("   " + e.getMessage());
        } catch (Exception e) {
            System.out.println("\n⚠️ ERRO INESPERADO:");
            e.printStackTrace();
        }
    }
}
