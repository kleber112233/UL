package parser;

import lexer.Token;
import lexer.Token.Tipo;
import errors.ParserError;
import java.util.List;

public class Parser {
    private final List<Token> tokens;
    private int pos = 0;

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
    }

    public void parse() {
        while (!isAtEnd()) {
            declaracaoOuComando();
        }
    }

    // =============== Declarações & Comandos ===============

    private void declaracaoOuComando() {
        if (match(Tipo.INT, Tipo.BOOL)) {
            // Declaração: <tipo> IDENT (= expr)?
            consumir(Tipo.IDENTIFICADOR, "Esperado identificador após tipo.");
            if (match(Tipo.ATRIBUICAO)) {
                expressao();
            }
            // PONTO_VIRGULA é opcional na sua linguagem de exemplo
            match(Tipo.PONTO_VIRGULA);
            return;
        }

        if (match(Tipo.OUT)) {
            consumir(Tipo.ABRE_PAR, "Esperado '(' após 'out'.");
            expressao();
            consumir(Tipo.FECHA_PAR, "Esperado ')' após expressão em 'out'.");
            match(Tipo.PONTO_VIRGULA);
            return;
        }

        if (match(Tipo.IF)) {
            consumir(Tipo.ABRE_PAR, "Esperado '(' após 'if'.");
            expressao();
            consumir(Tipo.FECHA_PAR, "Esperado ')' após condição do 'if'.");
            declaracaoOuComando();
            if (match(Tipo.ELSE)) {
                declaracaoOuComando();
            }
            consumir(Tipo.FIM, "Esperado 'fim' para encerrar o bloco do if.");
            return;
        }

        if (match(Tipo.LOOP)) {
            consumir(Tipo.ABRE_PAR, "Esperado '(' após 'loop'.");
            expressao();
            consumir(Tipo.FECHA_PAR, "Esperado ')' após condição do 'loop'.");
            declaracaoOuComando();
            consumir(Tipo.FIM, "Esperado 'fim' para encerrar o bloco do loop.");
            return;
        }

        // Atribuição como comando
        if (verificar(Tipo.IDENTIFICADOR)) {
            avancar(); // consome IDENT
            consumir(Tipo.ATRIBUICAO, "Esperado '=' em atribuição.");
            expressao();
            match(Tipo.PONTO_VIRGULA);
            return;
        }

        // Se nada acima bateu, tente expressão "solta" (opcional)
        expressao();
        match(Tipo.PONTO_VIRGULA);
    }

    // =============== Expressões (precedência) ===============

    private void expressao() {
        or();
    }

    private void or() {
        and();
        while (match(Tipo.OU_LOGICO)) {
            and();
        }
    }

    private void and() {
        igualdade();
        while (match(Tipo.E_LOGICO)) {
            igualdade();
        }
    }

    private void igualdade() {
        comparacao();
        while (match(Tipo.IGUAL, Tipo.DIFERENTE)) {
            comparacao();
        }
    }

    private void comparacao() {
        termo();
        while (match(Tipo.MAIOR, Tipo.MAIOR_IGUAL, Tipo.MENOR, Tipo.MENOR_IGUAL)) {
            termo();
        }
    }

    private void termo() {
        fator();
        while (match(Tipo.MAIS, Tipo.MENOS)) {
            fator();
        }
    }

    private void fator() {
        unario();
        while (match(Tipo.MULT, Tipo.DIV, Tipo.MOD)) {
            unario();
        }
    }

    private void unario() {
        if (match(Tipo.NEGACAO, Tipo.MENOS)) {
            unario();
        } else {
            primario();
        }
    }

    private void primario() {
        if (match(Tipo.NUMERO, Tipo.FLOAT, Tipo.BOOLEANO, Tipo.STRING, Tipo.IDENTIFICADOR)) {
            return;
        }
        if (match(Tipo.ABRE_PAR)) {
            expressao();
            consumir(Tipo.FECHA_PAR, "Esperado ')' após expressão.");
            return;
        }
        Token t = olhar();
        throw new ParserError("Expressão inválida perto de '" + t.getLexema() + "'", t.getLinha(), t.getColuna());
    }

    // =============== utilitários do parser ===============

    private boolean match(Token.Tipo... tipos) {
        for (Token.Tipo tipo : tipos) {
            if (verificar(tipo)) {
                avancar();
                return true;
            }
        }
        return false;
    }

    private Token consumir(Token.Tipo tipo, String mensagem) {
        if (verificar(tipo)) return avancar();
        Token t = olhar();
        throw new ParserError(mensagem, t.getLinha(), t.getColuna());
    }

    private boolean verificar(Token.Tipo tipo) {
        if (isAtEnd()) return false;
        return olhar().getTipo() == tipo;
    }

    private Token avancar() {
        if (!isAtEnd()) pos++;
        return anterior();
    }

    private boolean isAtEnd() {
        return olhar().getTipo() == Tipo.EOF;
    }

    private Token olhar() {
        return tokens.get(pos);
    }

    private Token anterior() {
        return tokens.get(pos - 1);
    }
}
