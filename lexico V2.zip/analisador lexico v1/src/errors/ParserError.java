package errors;

public class ParserError extends RuntimeException {
    public ParserError(String mensagem, int linha, int coluna) {
        super("Erro sintático na linha " + linha + ", coluna " + coluna + ": " + mensagem);
    }
}
