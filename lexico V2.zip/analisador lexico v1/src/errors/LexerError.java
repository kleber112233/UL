package errors;

/** Erro léxico: problemas encontrados pelo analisador léxico (Lexer). */
public class LexerError extends RuntimeException {
    private final int linha;
    private final int coluna;

    public LexerError(String mensagem, int linha, int coluna) {
        super("Erro léxico na linha " + linha + ", coluna " + coluna + ": " + mensagem);
        this.linha = linha;
        this.coluna = coluna;
    }

    public int getLinha() {
        return linha;
    }

    public int getColuna() {
        return coluna;
    }
}
