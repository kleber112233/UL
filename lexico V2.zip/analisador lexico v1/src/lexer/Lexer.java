package lexer;

import java.util.ArrayList;
import java.util.List;
import errors.LexerError;

/**
 * Analisador léxico da linguagem UL.
 * Converte o código-fonte em uma lista de tokens.
 *
 * Características:
 * - Princípio do match mais longo (operações de 2 caracteres têm prioridade).
 * - Bufferização por índices (inicio/atual) e lookahead (olhar, proximo, peek).
 * - Literais numéricas/booleanas/strings já com 'literal' preenchido.
 */
public class Lexer {
    private final String fonte;
    private final List<Token> tokens = new ArrayList<>();
    private int inicio = 0;  // início do lexema atual
    private int atual = 0;   // cursor na fonte
    private int linha = 1;
    private int coluna = 0;  // coluna do PRÓXIMO caractere a ser lido

    public Lexer(String fonte) {
        this.fonte = fonte;
    }

    public List<Token> analisar() {
        while (!fimDaFonte()) {
            inicio = atual;
            scanToken();
        }
        tokens.add(new Token(Token.Tipo.EOF, "", null, linha, 0));
        return tokens;
    }

    // ==================== núcleo ====================

    private void scanToken() {
        char c = avancar();
        switch (c) {
            // números iniciados por ponto: .5 etc (match mais longo garante float)
            case '.':
                if (Character.isDigit(olhar())) {
                    consumirNumeroComecandoComPonto();
                } else {
                    throw new LexerError("Ponto isolado encontrado.", linha, coluna);
                }
                break;

            // símbolos simples
            case '(': adicionarToken(Token.Tipo.ABRE_PAR); break;
            case ')': adicionarToken(Token.Tipo.FECHA_PAR); break;
            case '+': adicionarToken(Token.Tipo.MAIS); break;
            case '-': adicionarToken(Token.Tipo.MENOS); break;
            case '*': adicionarToken(Token.Tipo.MULT); break;
            case '%': adicionarToken(Token.Tipo.MOD); break;
            case ';': adicionarToken(Token.Tipo.PONTO_VIRGULA); break;

            // operadores compostos (longest match)
            case '=':
                if (combinar('=')) adicionarToken(Token.Tipo.IGUAL);
                else adicionarToken(Token.Tipo.ATRIBUICAO);
                break;

            case '!':
                if (combinar('=')) adicionarToken(Token.Tipo.DIFERENTE);
                else adicionarToken(Token.Tipo.NEGACAO);
                break;

            case '<':
                if (combinar('=')) adicionarToken(Token.Tipo.MENOR_IGUAL);
                else adicionarToken(Token.Tipo.MENOR);
                break;

            case '>':
                if (combinar('=')) adicionarToken(Token.Tipo.MAIOR_IGUAL);
                else adicionarToken(Token.Tipo.MAIOR);
                break;

            case '&':
                if (combinar('&')) adicionarToken(Token.Tipo.E_LOGICO);
                else throw new LexerError("Caractere '&' isolado. Use '&&'.", linha, coluna);
                break;

            case '|':
                if (combinar('|')) adicionarToken(Token.Tipo.OU_LOGICO);
                else throw new LexerError("Caractere '|' isolado. Use '||'.", linha, coluna);
                break;

            // divisão ou comentário
            case '/':
                if (combinar('/')) { // comentário de linha
                    while (olhar() != '\n' && !fimDaFonte()) avancar();
                } else if (combinar('*')) { // comentário de bloco
                    consumirComentarioBloco();
                } else {
                    adicionarToken(Token.Tipo.DIV);
                }
                break;

            // espaços em branco
            case ' ':
            case '\r':
            case '\t':
                break;

            case '\n':
                linha++;
                coluna = 0;
                break;

            // literais
            case '"':
                consumirString();
                break;

            default:
                if (Character.isDigit(c)) {
                    consumirNumero(c);
                } else if (Character.isLetter(c) || c == '_') {
                    consumirIdentOuPalavraChave();
                } else {
                    throw new LexerError("Caractere inesperado: '" + c + "'", linha, coluna);
                }
                break;
        }
    }

    // ==================== utilitários de buffer/lookahead ====================

    private boolean fimDaFonte() {
        return atual >= fonte.length();
    }

    private char avancar() {
        atual++;
        coluna++;
        return fonte.charAt(atual - 1);
    }

    private char olhar() {
        if (fimDaFonte()) return '\0';
        return fonte.charAt(atual);
    }

    private char proximo() {
        if (atual + 1 >= fonte.length()) return '\0';
        return fonte.charAt(atual + 1);
    }

    // Lookahead de N posições
    private char peek(int n) {
        int idx = atual + n;
        if (idx >= fonte.length()) return '\0';
        return fonte.charAt(idx);
    }

    private boolean combinar(char esperado) {
        if (fimDaFonte()) return false;
        if (fonte.charAt(atual) != esperado) return false;
        atual++;
        coluna++;
        return true;
    }

    private void adicionarToken(Token.Tipo tipo) {
        adicionarToken(tipo, null);
    }

    private void adicionarToken(Token.Tipo tipo, Object literal) {
        String texto = fonte.substring(inicio, atual);
        tokens.add(new Token(tipo, texto, literal, linha, Math.max(1, coluna - texto.length())));
    }

    // ==================== consumidores ====================

    private void consumirString() {
        StringBuilder valor = new StringBuilder();
        while (olhar() != '"' && !fimDaFonte()) {
            if (olhar() == '\n') {
                // strings com quebra de linha não são permitidas
                // se for desejado suportar, remova este bloco e apenas atualize linha/coluna.
                linha++;
                coluna = 0;
            }
            valor.append(avancar());
        }

        if (fimDaFonte()) {
            throw new LexerError("String não terminada.", linha, coluna);
        }

        avancar(); // consome o último '"'
        adicionarToken(Token.Tipo.STRING, valor.toString());
    }

    // número quando já consumimos o 1º dígito
    private void consumirNumero(char primeiro) {
        StringBuilder sb = new StringBuilder();
        sb.append(primeiro);

        while (Character.isDigit(olhar())) sb.append(avancar());

        // float?
        if (olhar() == '.') {
            if (Character.isDigit(proximo())) {
                sb.append(avancar()); // '.'
                while (Character.isDigit(olhar())) sb.append(avancar());
                // não permitir letra imediatamente após número
                if (Character.isLetter(olhar()) || olhar() == '_') {
                    throw new LexerError("Número malformado: '" + sb + olhar() + "'", linha, coluna);
                }
                adicionarToken(Token.Tipo.FLOAT, Double.parseDouble(sb.toString()));
                return;
            } else {
                throw new LexerError("Número decimal inválido: faltou dígito após o ponto em '" + sb + "'.", linha, coluna);
            }
        }

        if (Character.isLetter(olhar()) || olhar() == '_') {
            throw new LexerError("Número malformado: '" + sb + olhar() + "'", linha, coluna);
        }

        adicionarToken(Token.Tipo.NUMERO, Integer.parseInt(sb.toString()));
    }

    // número começando com ponto: .5
    private void consumirNumeroComecandoComPonto() {
        StringBuilder sb = new StringBuilder();
        sb.append('.');

        if (!Character.isDigit(olhar())) {
            throw new LexerError("Número decimal inválido: faltou dígito após '.'.", linha, coluna);
        }
        while (Character.isDigit(olhar())) sb.append(avancar());

        adicionarToken(Token.Tipo.FLOAT, Double.parseDouble(sb.toString()));
    }

    private void consumirIdentOuPalavraChave() {
        while (Character.isLetterOrDigit(olhar()) || olhar() == '_') {
            avancar();
        }
        String texto = fonte.substring(inicio, atual);

        switch (texto) {
            case "int":  adicionarToken(Token.Tipo.INT);  return;
            case "bool": adicionarToken(Token.Tipo.BOOL); return;
            case "true": adicionarToken(Token.Tipo.BOOLEANO, true);  return;
            case "false":adicionarToken(Token.Tipo.BOOLEANO, false); return;
            case "if":   adicionarToken(Token.Tipo.IF);   return;
            case "else": adicionarToken(Token.Tipo.ELSE); return;
            case "loop": adicionarToken(Token.Tipo.LOOP); return;
            case "out":  adicionarToken(Token.Tipo.OUT);  return;
            case "fim":  adicionarToken(Token.Tipo.FIM);  return;
            default:     adicionarToken(Token.Tipo.IDENTIFICADOR, texto);
        }
    }

    private void consumirComentarioBloco() {
        while (!fimDaFonte()) {
            if (olhar() == '*' && proximo() == '/') {
                avancar(); // '*'
                avancar(); // '/'
                return;
            }
            if (olhar() == '\n') {
                linha++;
                coluna = 0;
            }
            avancar();
        }
        throw new LexerError("Comentário de bloco não terminado.", linha, coluna);
    }
}
